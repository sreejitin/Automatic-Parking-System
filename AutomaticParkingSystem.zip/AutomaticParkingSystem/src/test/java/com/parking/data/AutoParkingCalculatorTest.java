package com.parking.data;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Test class for {@link AutoParkingCalculator}
 * @author jitinsreenivasan
 *
 */
@RunWith(SpringRunner.class)
public class AutoParkingCalculatorTest {

    @Test
    public void testAutoParkingPosForSampleData() throws Exception {

	assertEquals(AutoParkingCalculator.calculatePosition("5,5:RFLFRFLF"), "7,7");
	assertEquals(AutoParkingCalculator.calculatePosition("6,6:FFLFFLFFLFF"), "6,6");
	assertEquals(AutoParkingCalculator.calculatePosition("5,5:FLFLFFRFFF"), "4,1");

    }
    
    @Test
    public void testAutoParkingPosForValidData() throws Exception {
	
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:F"), "3,2");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:R"), "2,2");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:L"), "2,2");
	
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:FR"), "3,2");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:RF"), "2,3");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:LF"), "2,1");
	
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:FRF"), "3,3");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:RFL"), "2,3");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:LFR"), "2,1");
	
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:FRFl"), "3,3");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:RFLF"), "3,3");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:LFRF"), "3,1");
	
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:FRFlF"), "4,3");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:RFLFL"), "3,3");
	assertEquals(AutoParkingCalculator.calculatePosition("2,2:LFRFR"), "3,1");

	
    }
    
    @Test(expected = Exception.class)
    public void testAutoParkingPosForInvalidData() throws Exception {
	assertEquals(AutoParkingCalculator.calculatePosition("5,h:RFLFRFLF"), "7,7");
	assertEquals(AutoParkingCalculator.calculatePosition("5,5RFLFRFLF"), "7,7");
	assertEquals(AutoParkingCalculator.calculatePosition("5,5:RkddLFRFLF"), "7,7");
	
    }

}
