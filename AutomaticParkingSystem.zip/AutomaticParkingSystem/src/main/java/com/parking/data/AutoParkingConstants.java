package com.parking.data;

import java.util.HashMap;

/**
 * Class to store the constants.
 * @author jitinsreenivasan
 *
 */
public class AutoParkingConstants {

    public static String NORTH = "north";

    public static String SOUTH = "south";

    public static String EAST = "east";

    public static String WEST = "west";

    public static String INCREASE_X = "increase_x";

    public static String INCREASE_Y = "increase_y";

    public static String DECREASE_X = "decrease_x";

    public static String DECREASE_Y = "decrease_y";
    
    public static String R = "R";

    public static String L = "L";

    public static String F = "F";

    /**
     * Hasmap containing the set of direction rules as a key value pair to help determine car's position.
     */
    public static HashMap<String, String> DIRECTION_RULES = new HashMap<String, String>() {
	
	private static final long serialVersionUID = 1L;

	{
	    put(NORTH + R, EAST);
	    put(NORTH + L, WEST);
	    put(SOUTH + R, WEST);
	    put(SOUTH + L, EAST);
	    put(EAST + R, SOUTH);
	    put(EAST + L, NORTH);
	    put(WEST + R, NORTH);
	    put(WEST + L, SOUTH);
	    put(NORTH + F, INCREASE_Y);
	    put(SOUTH + F, DECREASE_Y);
	    put(EAST + F, INCREASE_X);
	    put(WEST + F, DECREASE_X);
	}
    };

}
