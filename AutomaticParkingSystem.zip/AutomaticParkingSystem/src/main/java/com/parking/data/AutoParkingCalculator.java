package com.parking.data;

import com.parking.data.AutoParkingConstants;

/**
 * Class containing the logic for calculating the new position of car based on
 * given instructions.
 * 
 * @author jitinsreenivasan
 * @version 1.0
 */
public class AutoParkingCalculator {

    /**
     * Method to take instruction as input, validate it and calculate car's new
     * position.
     * 
     * @param inputTxt e.g 5,5:RFLFFRFLF
     * @return new position of car
     * @throws Exception
     */
    public static String calculatePosition(String inputTxt) throws Exception {
	String currentDirection = AutoParkingConstants.NORTH;
	String txt[] = inputTxt.split(":");

	if (!txt[0].matches("^[0-9],[0-9]+$")) {
	    throw new Exception("Invalid input format");
	}
	txt[1] = txt[1].toUpperCase();
	if (!txt[1].matches("^[RFL]+$")) {

	    throw new Exception("Invalid input format");
	}

	String pos[] = txt[0].split(",");
	int ypos = Integer.parseInt(pos[0]);
	int xpos = Integer.parseInt(pos[1]);

	for (int i = 0; i < txt[1].length(); i++) {
	    char command = txt[1].charAt(i);

	    String directionRule = AutoParkingConstants.DIRECTION_RULES.get(currentDirection + command);

	    if (AutoParkingConstants.INCREASE_X.equals(directionRule)) {
		xpos++;
	    } else if (AutoParkingConstants.DECREASE_X.equals(directionRule)) {
		xpos--;
	    } else if (AutoParkingConstants.INCREASE_Y.equals(directionRule)) {
		ypos++;
	    } else if (AutoParkingConstants.DECREASE_Y.equals(directionRule)) {
		ypos--;
	    } else {
		currentDirection = directionRule;
	    }

	}

	return ypos + "," + xpos;
    }

}
