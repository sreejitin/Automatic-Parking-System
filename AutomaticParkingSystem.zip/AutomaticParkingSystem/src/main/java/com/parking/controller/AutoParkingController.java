package com.parking.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.parking.data.AutoParkingCalculator;

/**
 * Controller for accepting the input instruction and calculating the car's
 * parking position.
 * 
 * @author jitinsreenivasan
 * @version 1.0
 */
@Controller
public class AutoParkingController {
    final static Logger logger = LoggerFactory.getLogger(AutoParkingController.class);

    @GetMapping("/")
    public String index() {
	return "submit";
    }

    /**
     * Method to read input and pass for subsequent processing.
     * 
     * @param inputTxt
     *            input
     * @param redirectAttributes
     *            redirect Attributes
     * @return submit status
     * @throws Exception
     */
    @PostMapping("/submit")
    public String processInput(@RequestParam("inputTxt") String inputTxt, RedirectAttributes redirectAttributes)
	    throws Exception {

	if (inputTxt.isEmpty()) {
	    redirectAttributes.addFlashAttribute("errormessage", "Please enter the valid input");
	    return "redirect:submitStatus";
	}

	try {
	    String newPos = AutoParkingCalculator.calculatePosition(inputTxt);
	    redirectAttributes.addFlashAttribute("message", "The calculated new position of the car is " + newPos);

	} catch (Exception ex) {
	    logger.error("Error calculating car's position", ex);
	    redirectAttributes.addFlashAttribute("errormessage", ex.getMessage());
	    return "redirect:submitStatus";
	}

	return "redirect:/submitStatus";
    }

    @GetMapping("/submitStatus")
    public String submitStatus() {
	return "submitStatus";
    }

}
